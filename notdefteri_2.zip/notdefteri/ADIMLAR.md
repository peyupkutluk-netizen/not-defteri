# NotDefteri — Play Store'a Yükleme Adımları

## ADIM 1 — Vercel'e Yükle
1. github.com → yeni repo aç → bu klasörü yükle
2. vercel.com → "New Project" → GitHub repoyu seç
3. Build: `npm run build` | Output: `build`
4. Deploy et → URL al (örn: notdefteri.vercel.app)

## ADIM 2 — APK Oluştur
1. pwabuilder.com → URL'yi gir → "Package for stores"
2. Android seç → Package ID: `com.notdefteri.app`
3. Download → APK indir

## ADIM 3 — Play Console'a Yükle
1. play.google.com/console → 25$ hesap aç
2. "Uygulama oluştur" → bilgileri doldur
3. Görselleri yükle:
   - İkon (512x512) → public/icons/icon-512x512.png
   - Öne çıkan görsel (1024x500) → public/screenshots/feature_graphic.png
   - Ekran görüntüleri → public/screenshots/screen1.png, screen2.png
4. APK'yı "İç test" olarak yükle → 20 test kullanıcısı ekle
5. Onaydan sonra "Üretim" yayını yap

## Gizlilik Politikası URL
Play Store gizlilik politikası ister!
public/gizlilik-politikasi.html dosyasını Vercel URL'in ile yayınla:
https://notdefteri.vercel.app/gizlilik-politikasi.html
