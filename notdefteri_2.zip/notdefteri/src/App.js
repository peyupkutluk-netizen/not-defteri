import React, { useState, useEffect, useRef } from "react";

const COLORS = ["#f87171","#fb923c","#facc15","#4ade80","#60a5fa","#c084fc","#f472b6"];
const MONTHS = ["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"];
const WEEK_DAYS = ["Pt","Sa","Ça","Pe","Cu","Ct","Pz"];
const CATS = [{id:"all",label:"Tümü",icon:"🗂"},{id:"personal",label:"Kişisel",icon:"👤"},{id:"work",label:"İş",icon:"💼"},{id:"ideas",label:"Fikirler",icon:"💡"},{id:"shopping",label:"Alışveriş",icon:"🛒"}];
const PRIO = {low:{label:"Düşük",color:"#4ade80"},normal:{label:"Normal",color:"#60a5fa"},high:{label:"Yüksek",color:"#f87171"}};
const HOURS = Array.from({length:24},(_,i)=>i);
const HOUR_H = 64;
const GUN_ADLARI = ["Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi","Pazar"];
const GUN_KISA = ["Pzt","Sal","Çar","Per","Cum","Cmt","Paz"];
const ILISKI = ["Aile","Arkadaş","İş Arkadaşı","Sevgili","Diğer"];
const HEDEF_KATEGORILER = [
  {id:"saglik",label:"Sağlık",icon:"💪"},
  {id:"kariyer",label:"Kariyer",icon:"💼"},
  {id:"egitim",label:"Eğitim",icon:"📚"},
  {id:"kisisel",label:"Kişisel",icon:"🌱"},
  {id:"iliski",label:"İlişki",icon:"❤️"},
  {id:"finansal",label:"Finansal",icon:"💰"},
  {id:"diger",label:"Diğer",icon:"⭐"},
];
// Sabit Türk özel günleri (ay 1-12, gün)
const OZEL_GUNLER_SABIT = [
  // Milli & Resmi
  {ay:1,gun:1,ad:"Yılbaşı",emoji:"🎆",renk:"#facc15",tur:"resmi"},
  {ay:4,gun:23,ad:"23 Nisan Ulusal Egemenlik ve Çocuk Bayramı",emoji:"🎈",renk:"#4ade80",tur:"resmi"},
  {ay:5,gun:1,ad:"İşçi Bayramı",emoji:"✊",renk:"#f87171",tur:"resmi"},
  {ay:5,gun:19,ad:"Atatürk'ü Anma / Gençlik ve Spor Bayramı",emoji:"🏃",renk:"#60a5fa",tur:"resmi"},
  {ay:7,gun:15,ad:"Demokrasi ve Millî Birlik Günü",emoji:"🇹🇷",renk:"#f87171",tur:"resmi"},
  {ay:8,gun:30,ad:"30 Ağustos Zafer Bayramı",emoji:"🎖️",renk:"#f87171",tur:"resmi"},
  {ay:10,gun:29,ad:"Cumhuriyet Bayramı",emoji:"🇹🇷",renk:"#f87171",tur:"resmi"},
  // Sosyal
  {ay:2,gun:14,ad:"Sevgililer Günü",emoji:"❤️",renk:"#f472b6",tur:"sosyal"},
  {ay:3,gun:8,ad:"Dünya Kadınlar Günü",emoji:"♀️",renk:"#f472b6",tur:"sosyal"},
  {ay:3,gun:21,ad:"Nevruz",emoji:"🌸",renk:"#4ade80",tur:"sosyal"},
  {ay:4,gun:1,ad:"Nisan Şakası",emoji:"🤡",renk:"#facc15",tur:"sosyal"},
  {ay:11,gun:10,ad:"Atatürk'ü Anma (09:05)",emoji:"🕯️",renk:"#f87171",tur:"resmi"},
  {ay:12,gun:31,ad:"Yılbaşı Gecesi",emoji:"🎉",renk:"#facc15",tur:"sosyal"},
];

// Anneler Günü: Mayıs'ın 2. Pazarı, Babalar Günü: Haziran'ın 3. Pazarı
function annelerGunu(yil){
  let d=new Date(yil,4,1); // Mayıs 1
  const gun=(d.getDay()+6)%7; // 0=Pzt...6=Pzr → Pazar=6
  const ilkPazar=gun<=6?(7-gun)%7+1:1;
  const ikincPazar=ilkPazar+7;
  return String(ikincPazar).padStart(2,"0");
}
function babalarGunu(yil){
  let d=new Date(yil,5,1); // Haziran 1
  const gun=(d.getDay()+6)%7;
  const ilkPazar=gun<=6?(7-gun)%7+1:1;
  const ucuncuPazar=ilkPazar+14;
  return String(ucuncuPazar).padStart(2,"0");
}

// İslami bayramlar (yaklaşık, hicri takvime göre değişir - 2024-2027 için)
const ISLAMI_BAYRAMLAR = [
  // Ramazan Bayramı (Şeker Bayramı) - 1 gün arefe + 3 gün
  {tarih:"2025-03-29",ad:"Ramazan Bayramı Arifesi",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2025-03-30",ad:"Ramazan Bayramı 1. Günü",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2025-03-31",ad:"Ramazan Bayramı 2. Günü",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2025-04-01",ad:"Ramazan Bayramı 3. Günü",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  // Kurban Bayramı
  {tarih:"2025-06-05",ad:"Kurban Bayramı Arifesi",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2025-06-06",ad:"Kurban Bayramı 1. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2025-06-07",ad:"Kurban Bayramı 2. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2025-06-08",ad:"Kurban Bayramı 3. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2025-06-09",ad:"Kurban Bayramı 4. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  // Mevlid Kandili
  {tarih:"2025-09-04",ad:"Mevlid Kandili",emoji:"✨",renk:"#c084fc",tur:"dini"},
  // Regaip Kandili
  {tarih:"2025-01-30",ad:"Regaip Kandili",emoji:"✨",renk:"#c084fc",tur:"dini"},
  // Mirac Kandili
  {tarih:"2025-01-27",ad:"Miraç Kandili",emoji:"✨",renk:"#c084fc",tur:"dini"},
  // Berat Kandili
  {tarih:"2025-02-12",ad:"Berat Kandili",emoji:"✨",renk:"#c084fc",tur:"dini"},
  // Kadir Gecesi
  {tarih:"2025-03-27",ad:"Kadir Gecesi",emoji:"🌟",renk:"#c084fc",tur:"dini"},
  // Ramazan başlangıcı
  {tarih:"2025-03-01",ad:"Ramazan Başlangıcı",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  // 2026
  {tarih:"2026-03-19",ad:"Ramazan Bayramı Arifesi",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2026-03-20",ad:"Ramazan Bayramı 1. Günü",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2026-03-21",ad:"Ramazan Bayramı 2. Günü",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2026-03-22",ad:"Ramazan Bayramı 3. Günü",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2026-05-26",ad:"Kurban Bayramı Arifesi",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2026-05-27",ad:"Kurban Bayramı 1. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2026-05-28",ad:"Kurban Bayramı 2. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2026-05-29",ad:"Kurban Bayramı 3. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2026-05-30",ad:"Kurban Bayramı 4. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  // 2027
  {tarih:"2027-03-09",ad:"Ramazan Bayramı Arifesi",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2027-03-10",ad:"Ramazan Bayramı 1. Günü",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2027-03-11",ad:"Ramazan Bayramı 2. Günü",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2027-03-12",ad:"Ramazan Bayramı 3. Günü",emoji:"🌙",renk:"#c084fc",tur:"dini"},
  {tarih:"2027-05-16",ad:"Kurban Bayramı Arifesi",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2027-05-17",ad:"Kurban Bayramı 1. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2027-05-18",ad:"Kurban Bayramı 2. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2027-05-19",ad:"Kurban Bayramı 3. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
  {tarih:"2027-05-20",ad:"Kurban Bayramı 4. Günü",emoji:"🕌",renk:"#4ade80",tur:"dini"},
];


function getOzelGunler(yil,ay){
  const gunler=[];
  // Sabit günler
  OZEL_GUNLER_SABIT.forEach(g=>{if(g.ay===ay+1)gunler.push({...g,tarih:makeDayStr(yil,ay,g.gun)});});
  // Anneler günü (Mayıs 2. Pazar)
  if(ay===4){const gun=Number(annelerGunu(yil));gunler.push({tarih:makeDayStr(yil,ay,gun),ad:"Anneler Günü",emoji:"💐",renk:"#f472b6",tur:"sosyal"});}
  // Babalar günü (Haziran 3. Pazar)
  if(ay===5){const gun=Number(babalarGunu(yil));gunler.push({tarih:makeDayStr(yil,ay,gun),ad:"Babalar Günü",emoji:"👔",renk:"#60a5fa",tur:"sosyal"});}
  // İslami bayramlar
  const ayStr=String(ay+1).padStart(2,"0");
  ISLAMI_BAYRAMLAR.forEach(b=>{if(b.tarih.startsWith(`${yil}-${ayStr}`))gunler.push(b);});
  return gunler;
}
function getOzelGunByDate(ds){
  const d=new Date(ds+"T12:00:00");
  const yil=d.getFullYear(),ay=d.getMonth(),gun=d.getDate();
  const ayStr=String(ay+1).padStart(2,"0");
  const gunler=[];
  // Sabit
  OZEL_GUNLER_SABIT.forEach(g=>{if(g.ay===ay+1&&g.gun===gun)gunler.push(g);});
  // Anneler
  if(ay===4&&String(gun).padStart(2,"0")===annelerGunu(yil))gunler.push({ad:"Anneler Günü",emoji:"💐",renk:"#f472b6",tur:"sosyal"});
  // Babalar
  if(ay===5&&String(gun).padStart(2,"0")===babalarGunu(yil))gunler.push({ad:"Babalar Günü",emoji:"👔",renk:"#60a5fa",tur:"sosyal"});
  // İslami
  ISLAMI_BAYRAMLAR.forEach(b=>{if(b.tarih===ds)gunler.push(b);});
  return gunler;
}


function safeGet(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d;}catch{return d;}}
function safeSet(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch{}}
function toDateStr(d){return d.toISOString().split("T")[0];}
function makeDayStr(y,m,d){return `${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;}
function daysInMonth(y,m){return new Date(y,m+1,0).getDate();}
function firstDayOfMonth(y,m){return(new Date(y,m,1).getDay()+6)%7;}
function fmtDate(iso){return new Date(iso).toLocaleDateString("tr-TR",{day:"2-digit",month:"long",year:"numeric"});}
function fmtShort(ds){return new Date(ds+"T12:00:00").toLocaleDateString("tr-TR",{day:"numeric",month:"long"});}
function weekStart(date){const d=new Date(date);const day=(d.getDay()+6)%7;d.setDate(d.getDate()-day);return d;}
function addDays(date,n){const d=new Date(date);d.setDate(d.getDate()+n);return d;}
function todayDayIndex(){return(new Date().getDay()+6)%7;}
function gunKaldi(ay,gun){
  const bugun=new Date();
  const buYil=bugun.getFullYear();
  let sonraki=new Date(buYil,ay-1,gun);
  if(sonraki<bugun) sonraki=new Date(buYil+1,ay-1,gun);
  const fark=Math.ceil((sonraki-bugun)/(1000*60*60*24));
  return fark===0?"🎂 Bugün!":fark===1?"Yarın!":`${fark} gün`;
}
function yasHesapla(yil,ay,gun){
  if(!yil) return null;
  const b=new Date();
  let y=b.getFullYear()-Number(yil);
  if(b.getMonth()+1<ay||(b.getMonth()+1===ay&&b.getDate()<gun)) y--;
  return y;
}
function bugunDogumGunu(ay,gun){const b=new Date();return b.getMonth()+1===ay&&b.getDate()===gun;}
function yarinDogumGunu(ay,gun){const y=addDays(new Date(),1);return y.getMonth()+1===ay&&y.getDate()===gun;}

function Modal({children,onClose}){
  return(
    <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.78)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,padding:16}}>
      <div onClick={e=>e.stopPropagation()} style={{background:"#1c1c28",borderRadius:18,padding:28,width:480,maxWidth:"100%",maxHeight:"90vh",overflowY:"auto",border:"1px solid #2e2e40",boxShadow:"0 24px 80px rgba(0,0,0,0.8)"}}>
        {children}
      </div>
    </div>
  );
}

function DayColumn({dateStr,todayStr,accent,events,onSlotClick,onDeletePlan,hourHeight,compact}){
  const plans=events.filter(e=>e.date===dateStr&&e.planHour!==undefined);
  function getCols(items){
    const sorted=[...items].sort((a,b)=>a.planHour-b.planHour);
    const cols=[];
    sorted.forEach(p=>{
      const endH=p.planHour+(p.duration||60)/60;
      let placed=false;
      for(let ci=0;ci<cols.length;ci++){
        const last=cols[ci][cols[ci].length-1];
        const lastEnd=last.planHour+(last.duration||60)/60;
        if(p.planHour>=lastEnd){cols[ci].push(p);placed=true;break;}
      }
      if(!placed) cols.push([p]);
    });
    return cols;
  }
  const cols=getCols(plans);
  const tc=cols.length||1;
  return(
    <div style={{flex:1,minWidth:compact?80:100,background:"#1a1a26",borderRight:"1px solid #1e1e2e",position:"relative"}}>
      <div style={{height:40,background:"#13131e",borderBottom:"1px solid #252535",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",position:"sticky",top:0,zIndex:3}}>
        <span style={{fontSize:compact?9:10,color:dateStr===todayStr?accent:"#555",fontWeight:"bold"}}>{GUN_KISA[(new Date(dateStr+"T12:00:00").getDay()+6)%7]}</span>
        <span style={{fontSize:compact?11:13,color:dateStr===todayStr?accent:"#999",fontWeight:dateStr===todayStr?"bold":"normal"}}>{new Date(dateStr+"T12:00:00").getDate()}</span>
      </div>
      {HOURS.map(h=>{
        const ic=dateStr===todayStr&&new Date().getHours()===h;
        return(
          <div key={h} onClick={()=>onSlotClick(dateStr,h)} style={{height:hourHeight,borderBottom:"1px solid #1a1a22",position:"relative",cursor:"pointer",background:ic?`${accent}08`:"none"}}
            onMouseEnter={e=>e.currentTarget.style.background=ic?`${accent}14`:"#ffffff06"}
            onMouseLeave={e=>e.currentTarget.style.background=ic?`${accent}08`:"none"}>
            {ic&&<div style={{position:"absolute",left:0,top:0,bottom:0,width:2,background:accent}}/>}
          </div>
        );
      })}
      {cols.map((col,ci)=>col.map(p=>{
        const durH=(p.duration||60)/60;
        const bH=durH*hourHeight-4;
        const tP=p.planHour*hourHeight+40+2;
        const cW=100/tc;
        return(
          <div key={p.id} onClick={e=>{e.stopPropagation();onDeletePlan(p.id);}}
            style={{position:"absolute",top:tP,left:`${ci*cW+0.5}%`,width:`${cW-1}%`,height:bH,background:`${p.color}22`,border:`1px solid ${p.color}55`,borderLeft:`3px solid ${p.color}`,borderRadius:6,padding:"3px 6px",cursor:"pointer",zIndex:2,overflow:"hidden",boxSizing:"border-box"}}>
            <div style={{fontSize:compact?9:11,fontWeight:"bold",color:p.color,overflow:"hidden",whiteSpace:"nowrap",textOverflow:"ellipsis"}}>{p.title}</div>
            {!compact&&<div style={{fontSize:9,color:"#888"}}>{String(p.planHour).padStart(2,"0")}:00 · {p.duration}dk</div>}
          </div>
        );
      }))}

    </div>
  );
}

export default function App(){
  const [tab,setTab]=useState("notes");
  const [accent,setAccent]=useState(()=>safeGet("nd_accent","#6366f1"));
  const [notes,setNotes]=useState(()=>safeGet("nd_notes",[]));
  const [todos,setTodos]=useState(()=>safeGet("nd_todos",[]));
  const [events,setEvents]=useState(()=>safeGet("nd_events",[]));
  const [dersler,setDersler]=useState(()=>safeGet("nd_dersler",[]));
  const [odevler,setOdevler]=useState(()=>safeGet("nd_odevler",[]));
  const [dogumGunleri,setDogumGunleri]=useState(()=>safeGet("nd_dogumgunleri",[]));
  const [hedefler,setHedefler]=useState(()=>safeGet("nd_hedefler",[]));

  const [onboarding,setOnboarding]=useState(()=>safeGet("nd_onboarded",false)===false);
  const [onboardStep,setOnboardStep]=useState(0);
  const [showExport,setShowExport]=useState(false);
  const [catFilter,setCatFilter]=useState("all");
  const [search,setSearch]=useState("");

  const [showNote,setShowNote]=useState(false);
  const [viewNote,setViewNote]=useState(null);
  const [editNote,setEditNote]=useState(null);
  const [nf,setNf]=useState({title:"",content:"",color:"#60a5fa",category:"personal",tags:"",links:"",image:null});

  const [showTodo,setShowTodo]=useState(false);
  const [tf,setTf]=useState({title:"",priority:"normal",dueDate:""});

  const [calDate,setCalDate]=useState(new Date());
  const [selDay,setSelDay]=useState("");
  const [showEv,setShowEv]=useState(false);
  const [ef,setEf]=useState({title:"",time:"09:00",color:"#4ade80"});

  const [planDate,setPlanDate]=useState(new Date());
  const [planView,setPlanView]=useState("day");
  const [showPlanModal,setShowPlanModal]=useState(false);
  const [planSlot,setPlanSlot]=useState({date:"",hour:9});
  const [pf,setPf]=useState({title:"",color:"#60a5fa",duration:60,note:""});

  const [dersView,setDersView]=useState("program");
  const [showDersModal,setShowDersModal]=useState(false);
  const [showOdevModal,setShowOdevModal]=useState(false);
  const [editDers,setEditDers]=useState(null);
  const [df,setDf]=useState({ad:"",gun:0,baslangic:"08:00",bitis:"09:00",oda:"",ogretmen:"",color:"#60a5fa"});
  const [of2,setOf2]=useState({dersId:"",baslik:"",aciklama:"",tarih:"",onemli:false});
  const [selectedDersGun,setSelectedDersGun]=useState(todayDayIndex());

  const [dgAy,setDgAy]=useState(new Date().getMonth()+1);
  const [dgSearch,setDgSearch]=useState("");
  const [showDgModal,setShowDgModal]=useState(false);
  const [editDg,setEditDg]=useState(null);
  const [dgf,setDgf]=useState({ad:"",soyad:"",ay:1,gun:1,yil:"",iliski:"Arkadaş",color:"#f472b6",not:""});

  const [showHedefModal,setShowHedefModal]=useState(false);
  const [editHedef,setEditHedef]=useState(null);
  const [hf,setHf]=useState({baslik:"",aciklama:"",kategori:"kisisel",color:"#4ade80",adimlar:[]});
  const [hedefKatFilter,setHedefKatFilter]=useState("all");
  const [yeniAdim,setYeniAdim]=useState("");
  const fileRef=useRef(null);
  const todayStr=toDateStr(new Date());
  const buYil=new Date().getFullYear();

  useEffect(()=>{safeSet("nd_accent",accent);},[accent]);
  useEffect(()=>{safeSet("nd_notes",notes);},[notes]);
  useEffect(()=>{safeSet("nd_todos",todos);},[todos]);
  useEffect(()=>{safeSet("nd_events",events);},[events]);
  useEffect(()=>{safeSet("nd_dersler",dersler);},[dersler]);
  useEffect(()=>{safeSet("nd_odevler",odevler);},[odevler]);
  useEffect(()=>{safeSet("nd_dogumgunleri",dogumGunleri);},[dogumGunleri]);
  useEffect(()=>{safeSet("nd_hedefler",hedefler);},[hedefler]);
  // ---- NOT ----
  function openNewNote(){setEditNote(null);setNf({title:"",content:"",color:"#60a5fa",category:"personal",tags:"",links:"",image:null});setShowNote(true);}
  function openEditNote(n){setViewNote(n);}
  function startEdit(n){setEditNote(n);setNf({title:n.title,content:n.content,color:n.color,category:n.category||"personal",tags:(n.tags||[]).join(", "),links:(n.links||[]).join("\n"),image:n.image||null});setViewNote(null);setShowNote(true);}
  function saveNote(){
    if(!nf.title.trim()) return;
    const tags=nf.tags.split(",").map(t=>t.trim()).filter(Boolean);
    const links=nf.links.split("\n").map(l=>l.trim()).filter(Boolean);
    const now=new Date().toISOString();
    if(editNote){setNotes(prev=>prev.map(n=>n.id===editNote.id?{...n,...nf,tags,links,date:now}:n));}
    else{setNotes(prev=>[{id:Date.now(),...nf,tags,links,pinned:false,date:now},...prev]);}
    setShowNote(false);
  }
  function handleImage(e){const file=e.target.files[0];if(!file)return;const r=new FileReader();r.onload=ev=>setNf(p=>({...p,image:ev.target.result}));r.readAsDataURL(file);}

  // ---- YAPILACAK ----
  function addTodo(){
    if(!tf.title.trim()) return;
    setTodos(prev=>[{id:Date.now(),...tf,done:false,date:new Date().toISOString()},...prev]);
    setTf({title:"",priority:"normal",dueDate:""});
    setShowTodo(false);
  }

  // ---- AJANDA ----
  const cy=calDate.getFullYear(), cm=calDate.getMonth();
  function getEventsOnDay(d){return events.filter(e=>e.date===makeDayStr(cy,cm,d));}
  function openNewEvent(d){setSelDay(makeDayStr(cy,cm,d));setEf({title:"",time:"09:00",color:"#4ade80"});setShowEv(true);}
  function saveEvent(){if(!ef.title.trim())return;setEvents(prev=>[...prev,{id:Date.now(),date:selDay,...ef}]);setShowEv(false);}

  // ---- PLANLAYICI ----
  function openPlanSlot(ds,hour){setPlanSlot({date:ds,hour});setPf({title:"",color:"#60a5fa",duration:60,note:""});setShowPlanModal(true);}
  function savePlan(){
    if(!pf.title.trim()) return;
    setEvents(prev=>[...prev,{id:Date.now(),date:planSlot.date,title:pf.title,time:`${String(planSlot.hour).padStart(2,"0")}:00`,color:pf.color,duration:pf.duration,note:pf.note,planHour:planSlot.hour}]);
    setShowPlanModal(false);
  }

  // ---- DERS ----
  function saveDers(){
    if(!df.ad.trim()) return;
    if(editDers){setDersler(prev=>prev.map(d=>d.id===editDers.id?{...d,...df}:d));}
    else{setDersler(prev=>[...prev,{id:Date.now(),...df}]);}
    setShowDersModal(false);setEditDers(null);
  }
  function openEditDers(d){setEditDers(d);setDf({ad:d.ad,gun:d.gun,baslangic:d.baslangic,bitis:d.bitis,oda:d.oda||"",ogretmen:d.ogretmen||"",color:d.color});setShowDersModal(true);}
  function saveOdev(){
    if(!of2.baslik.trim()) return;
    setOdevler(prev=>[{id:Date.now(),...of2,tamamlandi:false,olusturma:new Date().toISOString()},...prev]);
    setOf2({dersId:"",baslik:"",aciklama:"",tarih:"",onemli:false});
    setShowOdevModal(false);
  }
  function toggleOdev(id){setOdevler(prev=>prev.map(o=>o.id===id?{...o,tamamlandi:!o.tamamlandi}:o));}

  // ---- DOĞUM GÜNÜ ----
  function saveDg(){
    if(!dgf.ad.trim()) return;
    if(editDg){setDogumGunleri(prev=>prev.map(d=>d.id===editDg.id?{...d,...dgf}:d));}
    else{setDogumGunleri(prev=>[...prev,{id:Date.now(),...dgf}]);}
    setShowDgModal(false);setEditDg(null);
  }
  function openEditDg(d){setEditDg(d);setDgf({ad:d.ad,soyad:d.soyad||"",ay:d.ay,gun:d.gun,yil:d.yil||"",iliski:d.iliski||"Arkadaş",color:d.color||"#f472b6",not:d.not||""});setShowDgModal(true);}

  // ---- HEDEF ----
  function openNewHedef(){setEditHedef(null);setHf({baslik:"",aciklama:"",kategori:"kisisel",color:"#4ade80",adimlar:[]});setYeniAdim("");setShowHedefModal(true);}
  function openEditHedef(h){setEditHedef(h);setHf({baslik:h.baslik,aciklama:h.aciklama||"",kategori:h.kategori,color:h.color,adimlar:h.adimlar||[]});setYeniAdim("");setShowHedefModal(true);}
  function adimEkle(){
    if(!yeniAdim.trim()) return;
    setHf(p=>({...p,adimlar:[...p.adimlar,{id:Date.now(),metin:yeniAdim.trim(),tamamlandi:false}]}));
    setYeniAdim("");
  }
  function saveHedef(){
    if(!hf.baslik.trim()) return;
    if(editHedef){setHedefler(prev=>prev.map(h=>h.id===editHedef.id?{...h,...hf,guncelleme:new Date().toISOString()}:h));}
    else{setHedefler(prev=>[{id:Date.now(),...hf,tamamlandi:false,olusturma:new Date().toISOString()},...prev]);}
    setShowHedefModal(false);setEditHedef(null);
  }
  function toggleHedef(id){
    setHedefler(prev=>prev.map(h=>h.id===id?{...h,tamamlandi:!h.tamamlandi,tamamlanmaTarihi:!h.tamamlandi?new Date().toISOString():null}:h));
  }
  function toggleAdim(hedefId,adimId){
    setHedefler(prev=>prev.map(h=>{
      if(h.id!==hedefId) return h;
      const adimlar=h.adimlar.map(a=>a.id===adimId?{...a,tamamlandi:!a.tamamlandi}:a);
      const hepsi=adimlar.length>0&&adimlar.every(a=>a.tamamlandi);
      return{...h,adimlar,tamamlandi:hepsi,tamamlanmaTarihi:hepsi?new Date().toISOString():null};
    }));
  }

  // ---- YEDEK ----
  function exportData(){
    const data={version:1,tarih:new Date().toISOString(),notes,todos,events,dersler,odevler,dogumGunleri,hedefler,accent};
    const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url;a.download=`notdefteri-yedek-${toDateStr(new Date())}.json`;a.click();
    URL.revokeObjectURL(url);
  }
  const importRef=React.useRef(null);
  function importData(e){
    const file=e.target.files[0];if(!file)return;
    const r=new FileReader();
    r.onload=ev=>{
      try{
        const d=JSON.parse(ev.target.result);
        if(d.notes)setNotes(d.notes);
        if(d.todos)setTodos(d.todos);
        if(d.events)setEvents(d.events);
        if(d.dersler)setDersler(d.dersler);
        if(d.odevler)setOdevler(d.odevler);
        if(d.dogumGunleri)setDogumGunleri(d.dogumGunleri);
        if(d.hedefler)setHedefler(d.hedefler);
        if(d.accent)setAccent(d.accent);
        setShowExport(false);
      }catch{console.error("Geçersiz dosya");}
    };
    r.readAsText(file);
    e.target.value="";
  }
  function completeOnboarding(){safeSet("nd_onboarded",true);setOnboarding(false);}

  // ---- HESAPLAMALAR ----
  const filteredNotes=notes
    .filter(n=>catFilter==="all"||n.category===catFilter)
    .filter(n=>n.title.toLowerCase().includes(search.toLowerCase())||n.content.toLowerCase().includes(search.toLowerCase())||(n.tags||[]).join(" ").toLowerCase().includes(search.toLowerCase()))
    .sort((a,b)=>(b.pinned?1:0)-(a.pinned?1:0)||new Date(b.date)-new Date(a.date));

  const bugunDg=dogumGunleri.filter(d=>bugunDogumGunu(d.ay,d.gun));
  const yarinDg=dogumGunleri.filter(d=>yarinDogumGunu(d.ay,d.gun));
  const yaklasanDglar=[...dogumGunleri].sort((a,b)=>{
    const ga=gunKaldi(a.ay,a.gun),gb=gunKaldi(b.ay,b.gun);
    const na=ga==="🎂 Bugün!"?0:ga==="Yarın!"?1:parseInt(ga);
    const nb=gb==="🎂 Bugün!"?0:gb==="Yarın!"?1:parseInt(gb);
    return na-nb;
  });
  const ayaDglar=dogumGunleri.filter(d=>d.ay===dgAy);
  const buAyDg=dogumGunleri.filter(d=>d.ay===new Date().getMonth()+1);
  const bekleyenOdevler=odevler.filter(o=>!o.tamamlandi);
  const todayEvs=events.filter(e=>e.date===todayStr).sort((a,b)=>a.time.localeCompare(b.time));
  const pendingCount=todos.filter(t=>!t.done).length;
  const planDateStr=toDateStr(planDate);
  const wStart=weekStart(planDate);
  const weekDays=Array.from({length:7},(_,i)=>{const d=addDays(wStart,i);return{str:toDateStr(d)};});
  const seciliGunDersler=dersler.filter(d=>d.gun===selectedDersGun).sort((a,b)=>a.baslangic.localeCompare(b.baslangic));
  const filtreliHedefler=hedefler.filter(h=>hedefKatFilter==="all"||h.kategori===hedefKatFilter);
  const tamamlananHedefler=hedefler.filter(h=>h.tamamlandi).length;
  const toplamHedef=hedefler.length;
  const hedefYuzde=toplamHedef>0?Math.round((tamamlananHedefler/toplamHedef)*100):0;

  const S={
    input:{width:"100%",padding:"9px 13px",borderRadius:9,background:"#111118",border:"1px solid #2e2e3e",color:"#e8e4dc",fontSize:14,fontFamily:"inherit",outline:"none",boxSizing:"border-box"},
    card:{background:"#1a1a26",borderRadius:13,border:"1px solid #252535",padding:18},
    btnP:(bg)=>({padding:"9px 20px",borderRadius:9,background:bg,color:"#fff",border:"none",cursor:"pointer",fontFamily:"inherit",fontSize:14,fontWeight:"bold"}),
    btnG:{padding:"9px 20px",borderRadius:9,background:"#252535",color:"#aaa",border:"none",cursor:"pointer",fontFamily:"inherit",fontSize:14},
  };

  return(
    <div style={{minHeight:"100vh",background:"#0d0d14",fontFamily:"Georgia,serif",color:"#e8e4dc",display:"flex",flexDirection:"column"}}>

      {/* ONBOARDING */}
    {onboarding&&(
      <div style={{position:"fixed",inset:0,background:"#0d0d14",zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center",padding:24}}>
        <div style={{maxWidth:460,width:"100%",position:"relative"}}>
          {onboardStep===0&&(
            <div style={{textAlign:"center"}}>
              <div style={{fontSize:64,marginBottom:16}}>📓</div>
              <div style={{fontSize:28,fontWeight:"bold",color:accent,marginBottom:10,letterSpacing:1}}>NotDefteri</div>
              <div style={{fontSize:15,color:"#888",lineHeight:1.7,marginBottom:32}}>Notlarını, görevlerini, ajandanı,<br/>doğum günlerini ve hedeflerini<br/>tek bir yerde yönet.</div>
              <button onClick={()=>setOnboardStep(1)} style={{padding:"14px 40px",borderRadius:14,background:accent,color:"#fff",border:"none",cursor:"pointer",fontFamily:"inherit",fontSize:16,fontWeight:"bold",width:"100%"}}>Başla →</button>
            </div>
          )}
          {onboardStep===1&&(
            <div style={{textAlign:"center"}}>
              <div style={{fontSize:52,marginBottom:16}}>🔒</div>
              <div style={{fontSize:22,fontWeight:"bold",color:"#e8e4dc",marginBottom:10}}>Gizliliğin Bizim İçin Önemli</div>
              <div style={{fontSize:14,color:"#888",lineHeight:1.8,marginBottom:28,textAlign:"left",background:"#1a1a26",borderRadius:14,padding:"18px 20px",border:"1px solid #252535"}}>
                <div style={{marginBottom:8}}>✅ Tüm veriler <strong style={{color:accent}}>yalnızca senin cihazında</strong> saklanır</div>
                <div style={{marginBottom:8}}>✅ Hiçbir sunucuya veri gönderilmez</div>
                <div style={{marginBottom:8}}>✅ İnternet bağlantısı gerekmez</div>
                <div>✅ İstediğin zaman yedeğini alabilirsin</div>
              </div>
              <button onClick={()=>setOnboardStep(2)} style={{padding:"14px 40px",borderRadius:14,background:accent,color:"#fff",border:"none",cursor:"pointer",fontFamily:"inherit",fontSize:16,fontWeight:"bold",width:"100%"}}>Anladım →</button>
            </div>
          )}
          {onboardStep===2&&(
            <div style={{textAlign:"center"}}>
              <div style={{fontSize:52,marginBottom:16}}>🎨</div>
              <div style={{fontSize:22,fontWeight:"bold",color:"#e8e4dc",marginBottom:10}}>Rengini Seç</div>
              <div style={{fontSize:14,color:"#666",marginBottom:24}}>İstediğin zaman değiştirebilirsin</div>
              <div style={{display:"flex",justifyContent:"center",gap:12,marginBottom:32,flexWrap:"wrap"}}>
                {COLORS.map(c=>(
                  <button key={c} onClick={()=>setAccent(c)} style={{width:44,height:44,borderRadius:"50%",background:c,border:accent===c?"4px solid #fff":"3px solid #333",cursor:"pointer",outline:"none",transition:"transform .15s",transform:accent===c?"scale(1.2)":"scale(1)"}}/>
                ))}
              </div>
              <button onClick={completeOnboarding} style={{padding:"14px 40px",borderRadius:14,background:accent,color:"#fff",border:"none",cursor:"pointer",fontFamily:"inherit",fontSize:16,fontWeight:"bold",width:"100%"}}>Uygulamaı Aç 🚀</button>
            </div>
          )}
          {onboardStep>0&&(
            <button onClick={()=>setOnboardStep(s=>s-1)} style={{position:"absolute",top:-40,left:0,background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:13,fontFamily:"inherit"}}>← Geri</button>
          )}
          <div style={{display:"flex",justifyContent:"center",gap:8,marginTop:28}}>
            {[0,1,2].map(i=><div key={i} style={{width:i===onboardStep?20:8,height:8,borderRadius:4,background:i===onboardStep?accent:"#252535",transition:"width .3s"}}/>)}
          </div>
        </div>
      </div>
    )}

    {/* HEADER */}
      <header style={{padding:"14px 24px",borderBottom:"1px solid #1e1e2e",background:"#11111a",display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:8}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:22,filter:`drop-shadow(0 0 8px ${accent})`}}>📓</span>
          <span style={{fontSize:18,fontWeight:"bold",letterSpacing:2,color:accent}}>NotDefteri</span>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{display:"flex",gap:5}}>
            {COLORS.map(c=>(
              <button key={c} onClick={()=>setAccent(c)} style={{width:17,height:17,borderRadius:"50%",background:c,border:accent===c?"3px solid #fff":"2px solid #333",cursor:"pointer",outline:"none"}}/>
            ))}
          </div>
          <button onClick={()=>setShowExport(true)} style={{padding:"6px 13px",borderRadius:8,background:"#1a1a26",border:"1px solid #252535",color:"#888",cursor:"pointer",fontFamily:"inherit",fontSize:12}}>💾 Yedek</button>
        </div>
      </header>

      {/* TABS */}
      <div style={{display:"flex",background:"#11111a",borderBottom:"1px solid #1e1e2e",overflowX:"auto"}}>
        {[["notes","📝 Notlar"],["todos","✅ Yapılacaklar"],["agenda","📅 Ajanda"],["planner","🕐 Planlayıcı"],["ders","🎓 Ders"],["dogum","🎂 Doğum"],["hedefler","🎯 Hedefler"]].map(([k,l])=>(
          <button key={k} onClick={()=>setTab(k)} style={{padding:"12px 18px",background:"none",border:"none",borderBottom:tab===k?`3px solid ${accent}`:"3px solid transparent",color:tab===k?accent:"#555",fontSize:13,fontFamily:"inherit",cursor:"pointer",fontWeight:tab===k?"bold":"normal",whiteSpace:"nowrap"}}>
            {l}
            {k==="todos"&&pendingCount>0&&<span style={{marginLeft:5,background:accent,color:"#fff",borderRadius:10,padding:"1px 6px",fontSize:11}}>{pendingCount}</span>}
            {k==="ders"&&bekleyenOdevler.length>0&&<span style={{marginLeft:5,background:"#f472b6",color:"#fff",borderRadius:10,padding:"1px 6px",fontSize:11}}>{bekleyenOdevler.length}</span>}
            {k==="dogum"&&bugunDg.length>0&&<span style={{marginLeft:5,background:"#fb923c",color:"#fff",borderRadius:10,padding:"1px 6px",fontSize:11}}>🎂</span>}
            {k==="hedefler"&&toplamHedef>0&&<span style={{marginLeft:5,background:"#4ade8088",color:"#fff",borderRadius:10,padding:"1px 6px",fontSize:11}}>{tamamlananHedefler}/{toplamHedef}</span>}
          </button>
        ))}
      </div>

      {/* İÇERİK */}
      <div style={{flex:1,padding:"22px 18px",maxWidth:1100,margin:"0 auto",width:"100%",boxSizing:"border-box"}}>

        {/* ---- NOTLAR ---- */}
        {tab==="notes"&&(
          <div>
            <div style={{display:"flex",gap:8,marginBottom:14,flexWrap:"wrap"}}>
              <input placeholder="🔍 Ara..." value={search} onChange={e=>setSearch(e.target.value)} style={{...S.input,flex:1,minWidth:150}}/>
              <button onClick={openNewNote} style={S.btnP(accent)}>+ Yeni Not</button>
            </div>
            <div style={{display:"flex",gap:6,marginBottom:18,flexWrap:"wrap"}}>
              {CATS.map(c=>(
                <button key={c.id} onClick={()=>setCatFilter(c.id)} style={{padding:"5px 13px",borderRadius:20,border:`1.5px solid ${catFilter===c.id?accent:"#252535"}`,background:catFilter===c.id?`${accent}22`:"none",color:catFilter===c.id?accent:"#666",cursor:"pointer",fontSize:12,fontFamily:"inherit"}}>{c.icon} {c.label}</button>
              ))}
            </div>
            {filteredNotes.length===0&&<div style={{textAlign:"center",color:"#444",marginTop:60,fontSize:15}}>Henüz not yok!</div>}
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(220px,1fr))",gap:14}}>
              {filteredNotes.map(note=>(
                <div key={note.id} onClick={()=>openEditNote(note)} style={{...S.card,borderLeft:`4px solid ${note.color}`,cursor:"pointer",transition:"transform .18s",boxShadow:`0 2px 16px ${note.color}12`}}
                  onMouseEnter={e=>e.currentTarget.style.transform="translateY(-3px)"}
                  onMouseLeave={e=>e.currentTarget.style.transform=""}>
                  {note.image&&<img src={note.image} alt="" style={{width:"100%",height:80,objectFit:"cover",borderRadius:7,marginBottom:10}}/>}
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:5}}>
                    <div style={{fontWeight:"bold",fontSize:14,color:note.color,flex:1,paddingRight:6}}>{note.title}</div>
                    <div style={{display:"flex",gap:2}}>
                      <button onClick={e=>{e.stopPropagation();setNotes(prev=>prev.map(n=>n.id===note.id?{...n,pinned:!n.pinned}:n));}} style={{background:"none",border:"none",cursor:"pointer",fontSize:12,color:note.pinned?"#facc15":"#444"}}>📌</button>
                      <button onClick={e=>{e.stopPropagation();setNotes(prev=>prev.filter(n=>n.id!==note.id));}} style={{background:"none",border:"none",cursor:"pointer",fontSize:12,color:"#f87171"}}>✕</button>
                    </div>
                  </div>
                  <div style={{fontSize:12,color:"#777",lineHeight:1.6,marginBottom:8,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:3,WebkitBoxOrient:"vertical"}}>{note.content||<span style={{color:"#444",fontStyle:"italic"}}>İçerik yok...</span>}</div>
                  {note.tags&&note.tags.length>0&&<div style={{display:"flex",gap:3,flexWrap:"wrap",marginBottom:5}}>{note.tags.map(t=><span key={t} style={{background:`${accent}20`,color:accent,borderRadius:8,padding:"1px 7px",fontSize:10}}>#{t}</span>)}</div>}
                  <div style={{fontSize:9,color:"#444",marginTop:6}}>{fmtDate(note.date)}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ---- YAPILACAKLAR ---- */}
        {tab==="todos"&&(
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
              <span style={{color:"#666",fontSize:14}}><span style={{color:accent,fontWeight:"bold"}}>{pendingCount}</span> bekleyen</span>
              <button onClick={()=>setShowTodo(true)} style={S.btnP(accent)}>+ Yeni Görev</button>
            </div>
            {todos.length===0&&<div style={{textAlign:"center",color:"#444",marginTop:60}}>Görev yok!</div>}
            {[false,true].map(done=>{
              const group=todos.filter(t=>t.done===done);
              if(!group.length) return null;
              return(
                <div key={String(done)} style={{marginBottom:24}}>
                  <div style={{fontSize:11,color:"#555",letterSpacing:2,marginBottom:10,fontWeight:"bold"}}>{done?"✅ TAMAMLANDI":"⏳ BEKLEYEN"}</div>
                  {group.map(t=>(
                    <div key={t.id} style={{...S.card,padding:"11px 14px",marginBottom:7,display:"flex",alignItems:"center",gap:11,borderLeft:`3px solid ${PRIO[t.priority].color}`,opacity:t.done?0.55:1}}>
                      <button onClick={()=>setTodos(prev=>prev.map(x=>x.id===t.id?{...x,done:!x.done}:x))} style={{width:21,height:21,borderRadius:"50%",border:`2px solid ${PRIO[t.priority].color}`,background:t.done?PRIO[t.priority].color:"none",cursor:"pointer",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:11}}>{t.done?"✓":""}</button>
                      <div style={{flex:1}}>
                        <div style={{fontSize:14,textDecoration:t.done?"line-through":"none",color:t.done?"#555":"#e8e4dc"}}>{t.title}</div>
                        {t.dueDate&&<div style={{fontSize:11,color:!t.done&&new Date(t.dueDate)<new Date()?"#f87171":"#555",marginTop:2}}>📅 {new Date(t.dueDate+"T12:00:00").toLocaleDateString("tr-TR",{day:"numeric",month:"long"})}</div>}
                      </div>
                      <span style={{fontSize:11,background:`${PRIO[t.priority].color}20`,color:PRIO[t.priority].color,borderRadius:7,padding:"2px 8px"}}>{PRIO[t.priority].label}</span>
                      <button onClick={()=>setTodos(prev=>prev.filter(x=>x.id!==t.id))} style={{background:"none",border:"none",color:"#f87171",cursor:"pointer",fontSize:14}}>✕</button>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        )}

        {/* ---- AJANDA ---- */}
        {tab==="agenda"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 270px",gap:22}}>
            <div>
              <div style={{...S.card,marginBottom:18}}>
                <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
                  <button onClick={()=>setCalDate(d=>new Date(d.getFullYear(),d.getMonth()-1,1))} style={{background:"none",border:"none",color:"#888",fontSize:20,cursor:"pointer"}}>‹</button>
                  <span style={{fontWeight:"bold",fontSize:16,color:accent}}>{MONTHS[cm]} {cy}</span>
                  <button onClick={()=>setCalDate(d=>new Date(d.getFullYear(),d.getMonth()+1,1))} style={{background:"none",border:"none",color:"#888",fontSize:20,cursor:"pointer"}}>›</button>
                </div>
                <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:10,fontSize:10}}>
                  {[["#f87171","Resmî Gün"],["#c084fc","Dini Bayram"],["#f472b6","Sosyal Gün"]].map(([c,l])=>(
                    <div key={l} style={{display:"flex",alignItems:"center",gap:4,color:"#555"}}><span style={{width:8,height:8,borderRadius:"50%",background:c,display:"inline-block"}}/>{l}</div>
                  ))}
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2}}>
                  {WEEK_DAYS.map(d=><div key={d} style={{textAlign:"center",fontSize:10,color:"#444",fontWeight:"bold",padding:"2px 0"}}>{d}</div>)}
                  {Array.from({length:firstDayOfMonth(cy,cm)}).map((_,i)=><div key={"e"+i}/>)}
                  {Array.from({length:daysInMonth(cy,cm)}).map((_,i)=>{
                    const d=i+1, ds=makeDayStr(cy,cm,d), isToday=ds===todayStr;
                    const hasEv=getEventsOnDay(d).length>0;
                    const hasDg=dogumGunleri.some(dg=>dg.ay===cm+1&&dg.gun===d);
                    const ozelGunler=getOzelGunByDate(ds);
                    // Öncelik: resmi > dini > sosyal
                    const ozelOnce=ozelGunler.find(g=>g.tur==="resmi")||ozelGunler.find(g=>g.tur==="dini")||ozelGunler.find(g=>g.tur==="sosyal");
                    const ozelRenk=ozelOnce?ozelOnce.renk:null;
                    const isBold=ozelOnce&&(ozelOnce.tur==="resmi"||ozelOnce.tur==="dini");
                    return(
                      <button key={d} onClick={()=>openNewEvent(d)} style={{padding:"8px 2px",borderRadius:6,border:isToday?`2px solid ${accent}`:ozelRenk?`1px solid ${ozelRenk}66`:"2px solid transparent",background:isToday?`${accent}20`:ozelRenk?`${ozelRenk}18`:"none",color:isToday?accent:ozelRenk||"#aaa",fontWeight:(isToday||isBold)?"bold":"normal",cursor:"pointer",fontSize:13,fontFamily:"inherit",position:"relative"}}
                        onMouseEnter={e=>{if(!isToday)e.currentTarget.style.opacity="0.8";}}
                        onMouseLeave={e=>e.currentTarget.style.opacity="1"}
                        title={ozelGunler.map(g=>g.emoji+" "+g.ad).join(" | ")||""}>
                        {d}
                        {hasDg&&<span style={{position:"absolute",top:1,right:2,fontSize:9,lineHeight:1}}>🎂</span>}
                        <div style={{position:"absolute",bottom:1,left:0,right:0,display:"flex",justifyContent:"center",gap:1}}>
                          {hasEv&&<span style={{width:4,height:4,borderRadius:"50%",background:accent,display:"inline-block"}}/>}
                          {ozelOnce&&<span style={{width:4,height:4,borderRadius:"50%",background:ozelRenk,display:"inline-block"}}/>}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
              {/* Özel Günler Bu Ay */}
              {(()=>{
                const ozelBuAy=getOzelGunler(cy,cm).sort((a,b)=>a.tarih.localeCompare(b.tarih));
                const dgBuAy=dogumGunleri.filter(d=>d.ay===cm+1).map(d=>({
                  tarih:makeDayStr(cy,cm,d.gun),
                  ad:"🎂 Doğum Günü",
                  isim:`${d.ad}${d.soyad?" "+d.soyad:""}`,
                  emoji:"🎂",
                  renk:d.color||"#f472b6",
                  tur:"dogum",
                  color:d.color||"#f472b6",
                })).sort((a,b)=>a.tarih.localeCompare(b.tarih));
                const tumGunler=[...ozelBuAy,...dgBuAy].sort((a,b)=>a.tarih.localeCompare(b.tarih));
                return tumGunler.length>0&&(
                <div style={{marginBottom:14}}>
                  <div style={{fontSize:11,color:"#555",letterSpacing:2,marginBottom:8,fontWeight:"bold"}}>✨ ÖZEL GÜNLER</div>
                  {tumGunler.map((g,i)=>(
                    <div key={i} style={{display:"flex",alignItems:"center",gap:9,padding:"7px 10px",borderRadius:9,marginBottom:5,background:`${g.renk}14`,borderLeft:`3px solid ${g.renk}`}}>
                      <span style={{fontSize:15}}>{g.emoji}</span>
                      <div style={{flex:1}}>
                        {g.tur==="dogum"
                          ?<div style={{fontSize:12,fontWeight:"bold",color:g.renk}}>{g.isim}</div>
                          :<div style={{fontSize:12,fontWeight:"bold",color:g.renk}}>{g.ad}</div>
                        }
                        <div style={{fontSize:10,color:"#555"}}>{new Date(g.tarih+"T12:00:00").toLocaleDateString("tr-TR",{day:"numeric",month:"long"})}{g.tur==="dogum"?" · Doğum Günü":""}</div>
                      </div>
                      <span style={{fontSize:9,background:`${g.renk}22`,color:g.renk,borderRadius:6,padding:"2px 6px"}}>{g.tur==="resmi"?"Resmi":g.tur==="dini"?"Dini":g.tur==="dogum"?"🎂":"Sosyal"}</span>
                    </div>
                  ))}
                </div>
              );})()}
              {events.filter(e=>e.date.startsWith(`${cy}-${String(cm+1).padStart(2,"0")}`)).sort((a,b)=>a.date.localeCompare(b.date)).map(ev=>(
                <div key={ev.id} style={{...S.card,padding:"9px 13px",marginBottom:7,display:"flex",alignItems:"center",gap:9,borderLeft:`3px solid ${ev.color}`}}>
                  <span style={{fontSize:11,color:"#555",minWidth:80}}>{ev.date.split("-").slice(1).reverse().join("/")} {ev.time}</span>
                  <span style={{flex:1,fontSize:13}}>{ev.title}</span>
                  <button onClick={()=>setEvents(prev=>prev.filter(e=>e.id!==ev.id))} style={{background:"none",border:"none",color:"#f87171",cursor:"pointer",fontSize:13}}>✕</button>
                </div>
              ))}
            </div>
            <div>
              <div style={{...S.card,marginBottom:14}}>
                <div style={{fontWeight:"bold",color:accent,marginBottom:3,fontSize:15}}>Bugün</div>
                <div style={{fontSize:11,color:"#555",marginBottom:14}}>{new Date().toLocaleDateString("tr-TR",{weekday:"long",day:"numeric",month:"long"})}</div>
                {todayEvs.map(ev=>(
                  <div key={ev.id} style={{padding:"9px 11px",borderRadius:8,marginBottom:7,background:`${ev.color}15`,borderLeft:`3px solid ${ev.color}`}}>
                    <div style={{fontWeight:"bold",fontSize:13}}>{ev.title}</div>
                    <div style={{fontSize:11,color:"#888",marginTop:2}}>🕐 {ev.time}</div>
                  </div>
                ))}
                {bugunDg.map(d=>(
                  <div key={d.id} style={{padding:"9px 11px",borderRadius:8,marginBottom:7,background:"#f472b618",borderLeft:"3px solid #f472b6"}}>
                    <div style={{fontWeight:"bold",fontSize:13}}>🎂 {d.ad} {d.soyad}</div>
                  </div>
                ))}
                {(()=>{const todayOzel=getOzelGunByDate(todayStr).filter(g=>g.tur!=="tatil");return todayOzel.map((g,i)=>(
                  <div key={"og"+i} style={{padding:"9px 11px",borderRadius:8,marginBottom:7,background:`${g.renk}18`,borderLeft:`3px solid ${g.renk}`}}>
                    <div style={{fontWeight:"bold",fontSize:13}}>{g.emoji} {g.ad}</div>
                  </div>
                ));})()}
                {todayEvs.length===0&&bugunDg.length===0&&getOzelGunByDate(todayStr).length===0&&<div style={{color:"#444",fontSize:12,textAlign:"center",padding:"10px 0"}}>Bugün etkinlik yok.</div>}
              </div>
              <div style={S.card}>
                <div style={{fontSize:11,color:"#444",letterSpacing:2,marginBottom:12,fontWeight:"bold"}}>ÖZET</div>
                {[["📝",`${notes.length} not`],["✅",`${pendingCount} bekleyen`],["🎂",`${dogumGunleri.length} doğum günü`],["🎯",`${tamamlananHedefler}/${toplamHedef} hedef`]].map(([ic,tx])=>(
                  <div key={tx} style={{display:"flex",gap:8,alignItems:"center",marginBottom:7,fontSize:13,color:"#888"}}><span>{ic}</span><span>{tx}</span></div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ---- PLANLAYICI ---- */}
        {tab==="planner"&&(
          <div>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:18,flexWrap:"wrap",gap:10}}>
              <div style={{display:"flex",gap:8,alignItems:"center"}}>
                <button onClick={()=>setPlanDate(d=>addDays(d,planView==="day"?-1:-7))} style={{...S.btnG,padding:"7px 14px"}}>‹</button>
                <div style={{fontWeight:"bold",fontSize:15,color:accent,minWidth:180,textAlign:"center"}}>
                  {planView==="day"?planDate.toLocaleDateString("tr-TR",{weekday:"long",day:"numeric",month:"long"}):`${fmtShort(toDateStr(wStart))} – ${fmtShort(toDateStr(addDays(wStart,6)))}`}
                </div>
                <button onClick={()=>setPlanDate(d=>addDays(d,planView==="day"?1:7))} style={{...S.btnG,padding:"7px 14px"}}>›</button>
                <button onClick={()=>setPlanDate(new Date())} style={{...S.btnG,padding:"7px 12px",fontSize:12,color:accent,border:`1px solid ${accent}40`}}>Bugün</button>
              </div>
              <div style={{display:"flex",gap:6}}>
                <button onClick={()=>setPlanView("day")} style={{padding:"7px 16px",borderRadius:8,background:planView==="day"?`${accent}22`:"none",border:`1.5px solid ${planView==="day"?accent:"#252535"}`,color:planView==="day"?accent:"#666",cursor:"pointer",fontFamily:"inherit",fontSize:13}}>Günlük</button>
                <button onClick={()=>setPlanView("week")} style={{padding:"7px 16px",borderRadius:8,background:planView==="week"?`${accent}22`:"none",border:`1.5px solid ${planView==="week"?accent:"#252535"}`,color:planView==="week"?accent:"#666",cursor:"pointer",fontFamily:"inherit",fontSize:13}}>Haftalık</button>
              </div>
            </div>
            <div style={{display:"flex",background:"#13131e",borderRadius:13,border:"1px solid #252535",overflow:"hidden"}}>
              <div style={{width:50,flexShrink:0,background:"#111118"}}>
                <div style={{height:40,borderBottom:"1px solid #252535"}}/>
                {HOURS.map(h=>(
                  <div key={h} style={{height:HOUR_H,borderBottom:"1px solid #1a1a22",display:"flex",alignItems:"flex-start",justifyContent:"flex-end",paddingRight:8,paddingTop:4}}>
                    <span style={{fontSize:10,color:"#444"}}>{String(h).padStart(2,"0")}:00</span>
                  </div>
                ))}
              </div>
              <div style={{flex:1,display:"flex",overflowX:"auto"}}>
                {planView==="day"
                  ?<DayColumn dateStr={planDateStr} todayStr={todayStr} accent={accent} events={events} onSlotClick={openPlanSlot} onDeletePlan={id=>setEvents(prev=>prev.filter(e=>e.id!==id))} hourHeight={HOUR_H} compact={false}/>
                  :weekDays.map(({str})=><DayColumn key={str} dateStr={str} todayStr={todayStr} accent={accent} events={events} onSlotClick={openPlanSlot} onDeletePlan={id=>setEvents(prev=>prev.filter(e=>e.id!==id))} hourHeight={HOUR_H} compact={true}/>)
                }
              </div>
            </div>
          </div>
        )}

        {/* ---- DERS ---- */}
        {tab==="ders"&&(
          <div>
            <div style={{display:"flex",gap:8,marginBottom:20,borderBottom:"1px solid #252535",paddingBottom:14,justifyContent:"space-between",flexWrap:"wrap"}}>
              <div style={{display:"flex",gap:6}}>
                <button onClick={()=>setDersView("program")} style={{padding:"7px 18px",borderRadius:9,background:dersView==="program"?`${accent}22`:"none",border:`1.5px solid ${dersView==="program"?accent:"#252535"}`,color:dersView==="program"?accent:"#666",cursor:"pointer",fontFamily:"inherit",fontSize:13}}>📋 Program</button>
                <button onClick={()=>setDersView("odevler")} style={{padding:"7px 18px",borderRadius:9,background:dersView==="odevler"?"#f472b622":"none",border:`1.5px solid ${dersView==="odevler"?"#f472b6":"#252535"}`,color:dersView==="odevler"?"#f472b6":"#666",cursor:"pointer",fontFamily:"inherit",fontSize:13}}>
                  📚 Ödevler{bekleyenOdevler.length>0&&<span style={{marginLeft:5,background:"#f472b6",color:"#fff",borderRadius:10,padding:"1px 6px",fontSize:11}}>{bekleyenOdevler.length}</span>}
                </button>
              </div>
              {dersView==="program"&&<button onClick={()=>{setEditDers(null);setDf({ad:"",gun:selectedDersGun,baslangic:"08:00",bitis:"09:00",oda:"",ogretmen:"",color:"#60a5fa"});setShowDersModal(true);}} style={S.btnP("#60a5fa")}>+ Ders Ekle</button>}
              {dersView==="odevler"&&<button onClick={()=>{setOf2({dersId:"",baslik:"",aciklama:"",tarih:"",onemli:false});setShowOdevModal(true);}} style={S.btnP("#f472b6")}>+ Ödev Ekle</button>}
            </div>
            {dersView==="program"&&(
              <div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:8,marginBottom:24}}>
                  {GUN_ADLARI.map((g,i)=>{
                    const gd=dersler.filter(d=>d.gun===i).sort((a,b)=>a.baslangic.localeCompare(b.baslangic));
                    const isToday=i===todayDayIndex();
                    return(
                      <div key={i} onClick={()=>setSelectedDersGun(i)} style={{background:selectedDersGun===i?`${accent}15`:"#1a1a26",borderRadius:11,border:`1.5px solid ${selectedDersGun===i?accent:isToday?`${accent}44`:"#252535"}`,padding:"10px 6px",cursor:"pointer",minHeight:80}}>
                        <div style={{textAlign:"center",fontSize:11,fontWeight:"bold",color:isToday?accent:selectedDersGun===i?accent:"#666",marginBottom:8}}>{GUN_KISA[i]}</div>
                        {gd.slice(0,3).map(d=>(
                          <div key={d.id} style={{background:`${d.color}22`,borderLeft:`2px solid ${d.color}`,borderRadius:4,padding:"2px 5px",marginBottom:3}}>
                            <div style={{fontSize:9,color:d.color,fontWeight:"bold",overflow:"hidden",whiteSpace:"nowrap",textOverflow:"ellipsis"}}>{d.ad}</div>
                            <div style={{fontSize:8,color:"#555"}}>{d.baslangic}</div>
                          </div>
                        ))}
                        {gd.length===0&&<div style={{fontSize:9,color:"#333",textAlign:"center",marginTop:8}}>boş</div>}
                      </div>
                    );
                  })}
                </div>
                <div style={{fontWeight:"bold",fontSize:16,color:accent,marginBottom:14}}>{GUN_ADLARI[selectedDersGun]} Dersleri</div>
                {seciliGunDersler.length===0&&<div style={{textAlign:"center",color:"#444",padding:"24px 0"}}>Bu gün ders yok!</div>}
                {seciliGunDersler.map(d=>(
                  <div key={d.id} style={{...S.card,borderLeft:`4px solid ${d.color}`,display:"flex",alignItems:"center",gap:14,padding:"14px 18px",marginBottom:10}}>
                    <div style={{width:44,height:44,borderRadius:10,background:`${d.color}22`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:20}}>📖</div>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:"bold",fontSize:15,color:d.color}}>{d.ad}</div>
                      <div style={{fontSize:12,color:"#888",marginTop:2}}>🕐 {d.baslangic} – {d.bitis}{d.oda&&` · 📍 ${d.oda}`}{d.ogretmen&&` · 👤 ${d.ogretmen}`}</div>
                    </div>
                    <div style={{display:"flex",gap:6}}>
                      <button onClick={()=>openEditDers(d)} style={{background:"none",border:"1px solid #333",borderRadius:7,color:"#aaa",cursor:"pointer",padding:"5px 10px",fontSize:12,fontFamily:"inherit"}}>Düzenle</button>
                      <button onClick={()=>setDersler(prev=>prev.filter(x=>x.id!==d.id))} style={{background:"none",border:"none",color:"#f87171",cursor:"pointer",fontSize:16}}>✕</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            {dersView==="odevler"&&(
              <div>
                {bekleyenOdevler.length===0&&<div style={{textAlign:"center",color:"#444",marginTop:40}}>Bekleyen ödev yok!</div>}
                {bekleyenOdevler.map(o=>{
                  const ders=dersler.find(d=>d.id===o.dersId);
                  const gecti=o.tarih&&new Date(o.tarih+"T23:59:59")<new Date();
                  return(
                    <div key={o.id} style={{...S.card,padding:"13px 16px",marginBottom:9,borderLeft:`4px solid ${ders?ders.color:"#f472b6"}`}}>
                      <div style={{display:"flex",alignItems:"flex-start",gap:10}}>
                        <button onClick={()=>toggleOdev(o.id)} style={{width:22,height:22,borderRadius:"50%",border:`2px solid ${ders?ders.color:"#f472b6"}`,background:"none",cursor:"pointer",flexShrink:0,marginTop:2}}/>
                        <div style={{flex:1}}>
                          <div style={{fontWeight:"bold",fontSize:14,color:ders?ders.color:"#f472b6"}}>{o.baslik}</div>
                          {ders&&<div style={{fontSize:11,color:"#777",marginTop:2}}>📖 {ders.ad}</div>}
                          {o.aciklama&&<div style={{fontSize:12,color:"#aaa",marginTop:4}}>{o.aciklama}</div>}
                          {o.tarih&&<div style={{fontSize:11,color:gecti?"#f87171":"#888",marginTop:6}}>📅 {new Date(o.tarih+"T12:00:00").toLocaleDateString("tr-TR",{day:"numeric",month:"long"})}{gecti&&" — GEÇTİ!"}</div>}
                        </div>
                        <button onClick={()=>setOdevler(prev=>prev.filter(x=>x.id!==o.id))} style={{background:"none",border:"none",color:"#f87171",cursor:"pointer",fontSize:14}}>✕</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ---- DOĞUM GÜNLERİ ---- */}
        {tab==="dogum"&&(
          <div>
            {(bugunDg.length>0||yarinDg.length>0)&&(
              <div style={{marginBottom:22}}>
                {bugunDg.map(d=>(
                  <div key={d.id} style={{background:"linear-gradient(135deg,#f472b622,#fb923c22)",border:"1.5px solid #f472b6",borderRadius:14,padding:"16px 20px",marginBottom:10,display:"flex",alignItems:"center",gap:14}}>
                    <span style={{fontSize:36}}>🎂</span>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:"bold",fontSize:18,color:"#f472b6"}}>{d.ad} {d.soyad}</div>
                      <div style={{fontSize:13,color:"#fb923c",marginTop:2}}>🎉 Bugün doğum günü!{d.yil&&` ${new Date().getFullYear()-Number(d.yil)} yaşına giriyor`}</div>
                    </div>
                  </div>
                ))}
                {yarinDg.map(d=>(
                  <div key={d.id} style={{background:"#facc1510",border:"1px solid #facc1544",borderRadius:14,padding:"14px 18px",marginBottom:10,display:"flex",alignItems:"center",gap:14}}>
                    <span style={{fontSize:28}}>🎈</span>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:"bold",fontSize:16,color:"#facc15"}}>{d.ad} {d.soyad}</div>
                      <div style={{fontSize:12,color:"#888",marginTop:2}}>Yarın doğum günü!</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div style={{display:"flex",gap:10,marginBottom:18,flexWrap:"wrap",justifyContent:"space-between",alignItems:"center"}}>
              <input placeholder="🔍 Kişi ara..." value={dgSearch} onChange={e=>setDgSearch(e.target.value)} style={{...S.input,maxWidth:280}}/>
              <button onClick={()=>{setEditDg(null);setDgf({ad:"",soyad:"",ay:1,gun:1,yil:"",iliski:"Arkadaş",color:"#f472b6",not:""});setShowDgModal(true);}} style={S.btnP("#f472b6")}>+ Doğum Günü Ekle</button>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
              <div>
                <div style={{fontSize:11,color:"#555",letterSpacing:2,marginBottom:14,fontWeight:"bold"}}>📅 YAKLAŞAN</div>
                {yaklasanDglar.filter(d=>`${d.ad} ${d.soyad||""}`.toLowerCase().includes(dgSearch.toLowerCase())).slice(0,15).map(d=>{
                  const kaldi=gunKaldi(d.ay,d.gun);
                  const bugun=kaldi==="🎂 Bugün!";
                  const yarin=kaldi==="Yarın!";
                  const yas=yasHesapla(d.yil,d.ay,d.gun);
                  return(
                    <div key={d.id} style={{...S.card,padding:"12px 14px",marginBottom:8,display:"flex",alignItems:"center",gap:12,borderLeft:`3px solid ${d.color}`,background:bugun?"#f472b615":yarin?"#facc1510":"#1a1a26"}}>
                      <div style={{width:38,height:38,borderRadius:"50%",background:`${d.color}22`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:16}}>{bugun?"🎂":yarin?"🎈":"👤"}</div>
                      <div style={{flex:1}}>
                        <div style={{fontWeight:"bold",fontSize:14,color:d.color}}>{d.ad} {d.soyad}</div>
                        <div style={{fontSize:11,color:"#888",marginTop:2}}>{d.gun} {MONTHS[d.ay-1]}{yas!==null&&` · ${bugun?yas:yas+1} yaş`}</div>
                      </div>
                      <div style={{fontWeight:"bold",fontSize:12,color:bugun?"#f472b6":yarin?"#facc15":accent,whiteSpace:"nowrap"}}>{kaldi}</div>
                      <div style={{display:"flex",flexDirection:"column",gap:3}}>
                        <button onClick={()=>openEditDg(d)} style={{background:"none",border:"1px solid #333",borderRadius:5,color:"#aaa",cursor:"pointer",padding:"3px 7px",fontSize:11}}>✎</button>
                        <button onClick={()=>setDogumGunleri(prev=>prev.filter(x=>x.id!==d.id))} style={{background:"none",border:"none",color:"#f87171",cursor:"pointer",fontSize:13}}>✕</button>
                      </div>
                    </div>
                  );
                })}
                {dogumGunleri.length===0&&<div style={{textAlign:"center",color:"#444",padding:"32px 0"}}>Henüz eklenmedi!</div>}
              </div>
              <div>
                <div style={{fontSize:11,color:"#555",letterSpacing:2,marginBottom:14,fontWeight:"bold"}}>🗓 AYA GÖRE</div>
                <div style={{...S.card,marginBottom:14}}>
                  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14}}>
                    <button onClick={()=>setDgAy(a=>a===1?12:a-1)} style={{background:"none",border:"none",color:"#888",fontSize:18,cursor:"pointer"}}>‹</button>
                    <span style={{fontWeight:"bold",fontSize:15,color:accent}}>{MONTHS[dgAy-1]}</span>
                    <button onClick={()=>setDgAy(a=>a===12?1:a+1)} style={{background:"none",border:"none",color:"#888",fontSize:18,cursor:"pointer"}}>›</button>
                  </div>
                  {ayaDglar.length===0
                    ?<div style={{textAlign:"center",color:"#444",padding:"16px 0",fontSize:13}}>Bu ayda kimse yok</div>
                    :[...ayaDglar].sort((a,b)=>a.gun-b.gun).map(d=>{
                      const b2=bugunDogumGunu(d.ay,d.gun);
                      return(
                        <div key={d.id} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 10px",borderRadius:9,marginBottom:6,background:b2?"#f472b615":`${d.color}10`,border:`1px solid ${b2?"#f472b644":`${d.color}30`}`}}>
                          <div style={{width:30,height:30,borderRadius:"50%",background:`${d.color}30`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:"bold",color:d.color,flexShrink:0}}>{d.gun}</div>
                          <div style={{flex:1}}>
                            <div style={{fontSize:13,fontWeight:"bold",color:d.color}}>{d.ad} {d.soyad}</div>
                            <div style={{fontSize:10,color:"#666"}}>{d.iliski}{d.yil&&` · ${new Date().getFullYear()-Number(d.yil)} yaş`}</div>
                          </div>
                          {b2&&<span>🎂</span>}
                        </div>
                      );
                    })
                  }
                </div>
                <div style={S.card}>
                  <div style={{fontSize:11,color:"#444",letterSpacing:2,marginBottom:12,fontWeight:"bold"}}>İSTATİSTİK</div>
                  {[["🎂",`${dogumGunleri.length} kişi`],["📅",`${buAyDg.length} bu ay`],["🎉",`${bugunDg.length} bugün`],["🎈",`${yarinDg.length} yarın`]].map(([ic,tx])=>(
                    <div key={tx} style={{display:"flex",gap:8,alignItems:"center",marginBottom:7,fontSize:13,color:"#888"}}><span>{ic}</span><span>{tx}</span></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ---- HEDEFLER ---- */}
        {tab==="hedefler"&&(
          <div>
            <div style={{...S.card,marginBottom:22,background:"linear-gradient(135deg,#1a1a26,#13131e)",borderTop:`3px solid ${accent}`}}>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16,flexWrap:"wrap",gap:10}}>
                <div>
                  <div style={{fontSize:22,fontWeight:"bold",color:accent}}>{buYil} Yılı Hedefleri 🎯</div>
                  <div style={{fontSize:13,color:"#666",marginTop:4}}>{tamamlananHedefler} tamamlandı · {toplamHedef-tamamlananHedefler} devam ediyor</div>
                </div>
                <button onClick={openNewHedef} style={S.btnP(accent)}>+ Hedef Ekle</button>
              </div>
              <div style={{marginBottom:8}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                  <span style={{fontSize:12,color:"#888"}}>Genel ilerleme</span>
                  <span style={{fontSize:14,fontWeight:"bold",color:accent}}>{hedefYuzde}%</span>
                </div>
                <div style={{height:10,borderRadius:5,background:"#1e1e2e",overflow:"hidden"}}>
                  <div style={{height:"100%",width:`${hedefYuzde}%`,background:`linear-gradient(90deg,${accent},${accent}99)`,borderRadius:5,transition:"width .6s ease"}}/>
                </div>
              </div>
              <div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:14}}>
                {HEDEF_KATEGORILER.map(kat=>{
                  const sayi=hedefler.filter(h=>h.kategori===kat.id).length;
                  if(!sayi) return null;
                  const tam=hedefler.filter(h=>h.kategori===kat.id&&h.tamamlandi).length;
                  return(
                    <div key={kat.id} style={{background:"#111118",borderRadius:9,padding:"6px 12px",display:"flex",alignItems:"center",gap:6}}>
                      <span style={{fontSize:14}}>{kat.icon}</span>
                      <span style={{fontSize:11,color:"#888"}}>{kat.label}</span>
                      <span style={{fontSize:11,fontWeight:"bold",color:tam===sayi?"#4ade80":accent}}>{tam}/{sayi}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div style={{display:"flex",gap:6,marginBottom:18,flexWrap:"wrap"}}>
              <button onClick={()=>setHedefKatFilter("all")} style={{padding:"5px 13px",borderRadius:20,border:`1.5px solid ${hedefKatFilter==="all"?accent:"#252535"}`,background:hedefKatFilter==="all"?`${accent}22`:"none",color:hedefKatFilter==="all"?accent:"#666",cursor:"pointer",fontSize:12,fontFamily:"inherit"}}>🗂 Tümü</button>
              {HEDEF_KATEGORILER.map(k=>(
                <button key={k.id} onClick={()=>setHedefKatFilter(k.id)} style={{padding:"5px 13px",borderRadius:20,border:`1.5px solid ${hedefKatFilter===k.id?accent:"#252535"}`,background:hedefKatFilter===k.id?`${accent}22`:"none",color:hedefKatFilter===k.id?accent:"#666",cursor:"pointer",fontSize:12,fontFamily:"inherit"}}>{k.icon} {k.label}</button>
              ))}
            </div>

            {filtreliHedefler.length===0&&<div style={{textAlign:"center",color:"#444",marginTop:60,fontSize:15}}>Henüz hedef eklenmedi! 🎯</div>}

            {filtreliHedefler.filter(h=>!h.tamamlandi).length>0&&(
              <div style={{marginBottom:28}}>
                <div style={{fontSize:11,color:"#888",letterSpacing:2,marginBottom:14,fontWeight:"bold"}}>🔥 DEVAM EDİYOR</div>
                {filtreliHedefler.filter(h=>!h.tamamlandi).map(h=>{
                  const kat=HEDEF_KATEGORILER.find(k=>k.id===h.kategori);
                  const adimToplam=h.adimlar?h.adimlar.length:0;
                  const adimTam=h.adimlar?h.adimlar.filter(a=>a.tamamlandi).length:0;
                  const adimYuzde=adimToplam>0?Math.round((adimTam/adimToplam)*100):0;
                  return(
                    <div key={h.id} style={{...S.card,borderLeft:`4px solid ${h.color}`,marginBottom:12,padding:"16px 18px"}}>
                      <div style={{display:"flex",alignItems:"flex-start",gap:12}}>
                        <button onClick={()=>toggleHedef(h.id)} title="Tamamlandı olarak işaretle"
                          style={{width:32,height:32,borderRadius:"50%",border:`2.5px solid ${h.color}`,background:"none",cursor:"pointer",flexShrink:0,marginTop:2,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,transition:"all .2s"}}
                          onMouseEnter={e=>e.currentTarget.style.background=`${h.color}30`}
                          onMouseLeave={e=>e.currentTarget.style.background="none"}>
                        </button>
                        <div style={{flex:1}}>
                          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4,flexWrap:"wrap"}}>
                            <span style={{fontSize:16}}>{kat?kat.icon:""}</span>
                            <div style={{fontWeight:"bold",fontSize:15,color:h.color}}>{h.baslik}</div>
                            <span style={{fontSize:10,background:`${h.color}20`,color:h.color,borderRadius:8,padding:"2px 8px"}}>{kat?kat.label:""}</span>
                          </div>
                          {h.aciklama&&<div style={{fontSize:12,color:"#888",marginBottom:10,lineHeight:1.6}}>{h.aciklama}</div>}
                          {adimToplam>0&&(
                            <div style={{marginBottom:10}}>
                              <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                                <span style={{fontSize:11,color:"#666"}}>Alt adımlar</span>
                                <span style={{fontSize:11,color:h.color,fontWeight:"bold"}}>{adimTam}/{adimToplam}</span>
                              </div>
                              <div style={{height:5,borderRadius:3,background:"#1e1e2e",overflow:"hidden",marginBottom:8}}>
                                <div style={{height:"100%",width:`${adimYuzde}%`,background:h.color,borderRadius:3,transition:"width .4s"}}/>
                              </div>
                              {h.adimlar.map(a=>(
                                <div key={a.id} onClick={()=>toggleAdim(h.id,a.id)}
                                  style={{display:"flex",alignItems:"center",gap:9,padding:"6px 8px",borderRadius:7,marginBottom:4,cursor:"pointer",background:a.tamamlandi?`${h.color}10`:"none",transition:"background .2s"}}
                                  onMouseEnter={e=>e.currentTarget.style.background=`${h.color}18`}
                                  onMouseLeave={e=>e.currentTarget.style.background=a.tamamlandi?`${h.color}10`:"none"}>
                                  <div style={{width:18,height:18,borderRadius:"50%",border:`2px solid ${a.tamamlandi?h.color:"#444"}`,background:a.tamamlandi?h.color:"none",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,color:"#fff",transition:"all .2s"}}>{a.tamamlandi?"✓":""}</div>
                                  <span style={{fontSize:13,color:a.tamamlandi?"#666":"#ccc",textDecoration:a.tamamlandi?"line-through":"none"}}>{a.metin}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                        <div style={{display:"flex",gap:5,flexShrink:0}}>
                          <button onClick={()=>openEditHedef(h)} style={{background:"none",border:"1px solid #333",borderRadius:7,color:"#aaa",cursor:"pointer",padding:"5px 9px",fontSize:12,fontFamily:"inherit"}}>✎</button>
                          <button onClick={()=>setHedefler(prev=>prev.filter(x=>x.id!==h.id))} style={{background:"none",border:"none",color:"#f87171",cursor:"pointer",fontSize:15}}>✕</button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {filtreliHedefler.filter(h=>h.tamamlandi).length>0&&(
              <div>
                <div style={{fontSize:11,color:"#4ade80",letterSpacing:2,marginBottom:14,fontWeight:"bold"}}>✅ TAMAMLANDI</div>
                {filtreliHedefler.filter(h=>h.tamamlandi).map(h=>{
                  const kat=HEDEF_KATEGORILER.find(k=>k.id===h.kategori);
                  return(
                    <div key={h.id} style={{...S.card,borderLeft:"4px solid #4ade80",marginBottom:10,padding:"14px 18px",opacity:0.7}}>
                      <div style={{display:"flex",alignItems:"center",gap:12}}>
                        <button onClick={()=>toggleHedef(h.id)} style={{width:32,height:32,borderRadius:"50%",border:"2.5px solid #4ade80",background:"#4ade80",cursor:"pointer",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,color:"#0d0d14",fontWeight:"bold"}}>✓</button>
                        <div style={{flex:1}}>
                          <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
                            <span style={{fontSize:15}}>{kat?kat.icon:""}</span>
                            <div style={{fontWeight:"bold",fontSize:14,color:"#4ade80",textDecoration:"line-through"}}>{h.baslik}</div>
                          </div>
                          {h.tamamlanmaTarihi&&<div style={{fontSize:10,color:"#4ade8088",marginTop:3}}>✅ {new Date(h.tamamlanmaTarihi).toLocaleDateString("tr-TR",{day:"numeric",month:"long"})}</div>}
                        </div>
                        <button onClick={()=>setHedefler(prev=>prev.filter(x=>x.id!==h.id))} style={{background:"none",border:"none",color:"#f87171",cursor:"pointer",fontSize:15}}>✕</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}


      </div>

      {/* ======== MODALLER ======== */}

      {/* NOT OKUMA MODU */}
      {viewNote&&(
        <div onClick={()=>setViewNote(null)} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,padding:20}}>
          <div onClick={e=>e.stopPropagation()} style={{background:"#13131e",borderRadius:20,width:"100%",maxWidth:780,maxHeight:"90vh",display:"flex",flexDirection:"column",border:`1px solid ${viewNote.color}44`,boxShadow:`0 32px 80px rgba(0,0,0,0.8),0 0 0 1px ${viewNote.color}22`,overflow:"hidden"}}>
            {/* Başlık çubuğu */}
            <div style={{padding:"20px 28px",borderBottom:`1px solid ${viewNote.color}33`,background:`${viewNote.color}0d`,display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12,flexShrink:0}}>
              <div style={{flex:1}}>
                <div style={{fontSize:22,fontWeight:"bold",color:viewNote.color,lineHeight:1.3,marginBottom:6}}>{viewNote.title}</div>
                <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"center"}}>
                  {viewNote.tags&&viewNote.tags.length>0&&viewNote.tags.map(t=><span key={t} style={{background:`${viewNote.color}22`,color:viewNote.color,borderRadius:8,padding:"2px 9px",fontSize:11}}>#{t}</span>)}
                  <span style={{fontSize:11,color:"#555"}}>{fmtDate(viewNote.date)}</span>
                  {viewNote.pinned&&<span style={{fontSize:12}}>📌</span>}
                </div>
              </div>
              <div style={{display:"flex",gap:8,flexShrink:0}}>
                <button onClick={()=>startEdit(viewNote)} style={{padding:"8px 16px",borderRadius:9,background:`${viewNote.color}22`,border:`1px solid ${viewNote.color}55`,color:viewNote.color,cursor:"pointer",fontFamily:"inherit",fontSize:13,fontWeight:"bold"}}>✎ Düzenle</button>
                <button onClick={()=>setViewNote(null)} style={{width:34,height:34,borderRadius:"50%",background:"#252535",border:"none",color:"#888",cursor:"pointer",fontSize:18,display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
              </div>
            </div>
            {/* İçerik */}
            <div style={{flex:1,overflowY:"auto",padding:"28px 32px"}}>
              {viewNote.image&&<img src={viewNote.image} alt="" style={{width:"100%",maxHeight:320,objectFit:"cover",borderRadius:12,marginBottom:24}}/>}
              <div style={{fontSize:16,color:"#d8d4cc",lineHeight:1.9,whiteSpace:"pre-wrap",fontFamily:"Georgia,serif"}}>{viewNote.content||<span style={{color:"#444",fontStyle:"italic"}}>İçerik yok...</span>}</div>
              {viewNote.links&&viewNote.links.length>0&&(
                <div style={{marginTop:28,paddingTop:20,borderTop:"1px solid #1e1e2e"}}>
                  <div style={{fontSize:11,color:"#555",letterSpacing:2,marginBottom:10,fontWeight:"bold"}}>🔗 LİNKLER</div>
                  {viewNote.links.map((l,i)=><a key={i} href={l} target="_blank" rel="noreferrer" style={{display:"block",color:viewNote.color,fontSize:13,marginBottom:6,wordBreak:"break-all"}}>{l}</a>)}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* NOT DÜZENLEME MODU */}
      {showNote&&(
        <Modal onClose={()=>setShowNote(false)}>
          <div style={{fontWeight:"bold",fontSize:17,marginBottom:16,color:nf.color}}>{editNote?"Notu Düzenle":"✏️ Yeni Not"}</div>
          <input placeholder="Başlık *" value={nf.title} onChange={e=>setNf(p=>({...p,title:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <textarea placeholder="İçerik..." value={nf.content} onChange={e=>setNf(p=>({...p,content:e.target.value}))} rows={10} style={{...S.input,resize:"vertical",marginBottom:9,lineHeight:1.7}}/>
          <select value={nf.category} onChange={e=>setNf(p=>({...p,category:e.target.value}))} style={{...S.input,marginBottom:9}}>
            {CATS.filter(c=>c.id!=="all").map(c=><option key={c.id} value={c.id}>{c.icon} {c.label}</option>)}
          </select>
          <input placeholder="Etiketler (virgülle ayır)" value={nf.tags} onChange={e=>setNf(p=>({...p,tags:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <textarea placeholder="Linkler (her satıra bir)" value={nf.links} onChange={e=>setNf(p=>({...p,links:e.target.value}))} rows={2} style={{...S.input,resize:"vertical",marginBottom:9}}/>
          <div style={{marginBottom:12}}>
            <button onClick={()=>fileRef.current&&fileRef.current.click()} style={{...S.btnP("#252535"),fontSize:12,padding:"7px 13px"}}>📷 Görsel Ekle</button>
            <input ref={fileRef} type="file" accept="image/*" onChange={handleImage} style={{display:"none"}}/>
            {nf.image&&<span style={{marginLeft:9,fontSize:12,color:"#4ade80"}}>✓ Seçildi</span>}
          </div>
          <div style={{display:"flex",gap:5,marginBottom:16}}>{COLORS.map(c=><button key={c} onClick={()=>setNf(p=>({...p,color:c}))} style={{width:21,height:21,borderRadius:"50%",background:c,border:nf.color===c?"3px solid #fff":"2px solid #333",cursor:"pointer",outline:"none"}}/>)}</div>
          <div style={{display:"flex",gap:7,justifyContent:"flex-end"}}>
            <button onClick={()=>setShowNote(false)} style={S.btnG}>İptal</button>
            <button onClick={saveNote} style={S.btnP(nf.color)}>Kaydet</button>
          </div>
        </Modal>
      )}

      {showTodo&&(
        <Modal onClose={()=>setShowTodo(false)}>
          <div style={{fontWeight:"bold",fontSize:17,marginBottom:16,color:accent}}>Yeni Görev</div>
          <input placeholder="Görev adı *" value={tf.title} onChange={e=>setTf(p=>({...p,title:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <select value={tf.priority} onChange={e=>setTf(p=>({...p,priority:e.target.value}))} style={{...S.input,marginBottom:9}}>
            <option value="low">🟢 Düşük</option>
            <option value="normal">🔵 Normal</option>
            <option value="high">🔴 Yüksek</option>
          </select>
          <div style={{fontSize:12,color:"#555",marginBottom:4}}>Son tarih</div>
          <input type="date" value={tf.dueDate} onChange={e=>setTf(p=>({...p,dueDate:e.target.value}))} style={{...S.input,marginBottom:16}}/>
          <div style={{display:"flex",gap:7,justifyContent:"flex-end"}}>
            <button onClick={()=>setShowTodo(false)} style={S.btnG}>İptal</button>
            <button onClick={addTodo} style={S.btnP(accent)}>Ekle</button>
          </div>
        </Modal>
      )}

      {showEv&&(
        <Modal onClose={()=>setShowEv(false)}>
          <div style={{fontWeight:"bold",fontSize:17,marginBottom:6,color:accent}}>Etkinlik Ekle</div>
          <div style={{fontSize:12,color:"#555",marginBottom:14}}>📅 {selDay&&new Date(selDay+"T12:00:00").toLocaleDateString("tr-TR",{day:"numeric",month:"long",year:"numeric"})}</div>
          <input placeholder="Etkinlik adı *" value={ef.title} onChange={e=>setEf(p=>({...p,title:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <input type="time" value={ef.time} onChange={e=>setEf(p=>({...p,time:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <div style={{display:"flex",gap:5,marginBottom:16}}>{COLORS.map(c=><button key={c} onClick={()=>setEf(p=>({...p,color:c}))} style={{width:21,height:21,borderRadius:"50%",background:c,border:ef.color===c?"3px solid #fff":"2px solid #333",cursor:"pointer",outline:"none"}}/>)}</div>
          <div style={{display:"flex",gap:7,justifyContent:"flex-end"}}>
            <button onClick={()=>setShowEv(false)} style={S.btnG}>İptal</button>
            <button onClick={saveEvent} style={S.btnP(accent)}>Ekle</button>
          </div>
        </Modal>
      )}

      {showPlanModal&&(
        <Modal onClose={()=>setShowPlanModal(false)}>
          <div style={{fontWeight:"bold",fontSize:17,marginBottom:6,color:accent}}>Zaman Bloğu</div>
          <div style={{fontSize:12,color:"#555",marginBottom:16}}>🕐 {String(planSlot.hour).padStart(2,"0")}:00</div>
          <input placeholder="Başlık *" value={pf.title} onChange={e=>setPf(p=>({...p,title:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <textarea placeholder="Not..." value={pf.note} onChange={e=>setPf(p=>({...p,note:e.target.value}))} rows={3} style={{...S.input,resize:"vertical",marginBottom:9}}/>
          <select value={pf.duration} onChange={e=>setPf(p=>({...p,duration:Number(e.target.value)}))} style={{...S.input,marginBottom:14}}>
            {[30,60,90,120,150,180,240].map(d=><option key={d} value={d}>{d} dk</option>)}
          </select>
          <div style={{display:"flex",gap:5,marginBottom:14}}>{COLORS.map(c=><button key={c} onClick={()=>setPf(p=>({...p,color:c}))} style={{width:21,height:21,borderRadius:"50%",background:c,border:pf.color===c?"3px solid #fff":"2px solid #333",cursor:"pointer",outline:"none"}}/>)}</div>
          <div style={{background:`${pf.color}15`,borderLeft:`3px solid ${pf.color}`,borderRadius:8,padding:"8px 12px",marginBottom:16,fontSize:12,color:"#aaa"}}>
            ⏱ {String(planSlot.hour).padStart(2,"0")}:00 → {String(Math.floor(planSlot.hour+pf.duration/60)).padStart(2,"0")}:{String(pf.duration%60).padStart(2,"0")} · {pf.duration} dk
          </div>
          <div style={{display:"flex",gap:7,justifyContent:"flex-end"}}>
            <button onClick={()=>setShowPlanModal(false)} style={S.btnG}>İptal</button>
            <button onClick={savePlan} style={S.btnP(accent)}>Ekle</button>
          </div>
        </Modal>
      )}

      {showDersModal&&(
        <Modal onClose={()=>setShowDersModal(false)}>
          <div style={{fontWeight:"bold",fontSize:17,marginBottom:16,color:"#60a5fa"}}>{editDers?"Dersi Düzenle":"Yeni Ders"}</div>
          <input placeholder="Ders adı *" value={df.ad} onChange={e=>setDf(p=>({...p,ad:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <select value={df.gun} onChange={e=>setDf(p=>({...p,gun:Number(e.target.value)}))} style={{...S.input,marginBottom:9}}>
            {GUN_ADLARI.map((g,i)=><option key={i} value={i}>{g}</option>)}
          </select>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9,marginBottom:9}}>
            <div><div style={{fontSize:12,color:"#555",marginBottom:4}}>Başlangıç</div><input type="time" value={df.baslangic} onChange={e=>setDf(p=>({...p,baslangic:e.target.value}))} style={S.input}/></div>
            <div><div style={{fontSize:12,color:"#555",marginBottom:4}}>Bitiş</div><input type="time" value={df.bitis} onChange={e=>setDf(p=>({...p,bitis:e.target.value}))} style={S.input}/></div>
          </div>
          <input placeholder="Sınıf / Oda" value={df.oda} onChange={e=>setDf(p=>({...p,oda:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <input placeholder="Öğretmen" value={df.ogretmen} onChange={e=>setDf(p=>({...p,ogretmen:e.target.value}))} style={{...S.input,marginBottom:12}}/>
          <div style={{display:"flex",gap:5,marginBottom:18}}>{COLORS.map(c=><button key={c} onClick={()=>setDf(p=>({...p,color:c}))} style={{width:24,height:24,borderRadius:"50%",background:c,border:df.color===c?"3px solid #fff":"2px solid #333",cursor:"pointer",outline:"none"}}/>)}</div>
          <div style={{display:"flex",gap:7,justifyContent:"flex-end"}}>
            <button onClick={()=>{setShowDersModal(false);setEditDers(null);}} style={S.btnG}>İptal</button>
            <button onClick={saveDers} style={S.btnP("#60a5fa")}>Kaydet</button>
          </div>
        </Modal>
      )}

      {showOdevModal&&(
        <Modal onClose={()=>setShowOdevModal(false)}>
          <div style={{fontWeight:"bold",fontSize:17,marginBottom:16,color:"#f472b6"}}>📚 Ödev Ekle</div>
          <select value={of2.dersId} onChange={e=>setOf2(p=>({...p,dersId:e.target.value}))} style={{...S.input,marginBottom:9}}>
            <option value="">— Ders seç (opsiyonel) —</option>
            {dersler.map(d=><option key={d.id} value={d.id}>{d.ad}</option>)}
          </select>
          <input placeholder="Başlık *" value={of2.baslik} onChange={e=>setOf2(p=>({...p,baslik:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <textarea placeholder="Açıklama..." value={of2.aciklama} onChange={e=>setOf2(p=>({...p,aciklama:e.target.value}))} rows={3} style={{...S.input,resize:"vertical",marginBottom:9}}/>
          <input type="date" value={of2.tarih} onChange={e=>setOf2(p=>({...p,tarih:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <label style={{display:"flex",alignItems:"center",gap:8,marginBottom:18,cursor:"pointer",fontSize:13,color:"#999"}}>
            <input type="checkbox" checked={of2.onemli} onChange={e=>setOf2(p=>({...p,onemli:e.target.checked}))} style={{width:15,height:15}}/>⚠️ Önemli
          </label>
          <div style={{display:"flex",gap:7,justifyContent:"flex-end"}}>
            <button onClick={()=>setShowOdevModal(false)} style={S.btnG}>İptal</button>
            <button onClick={saveOdev} style={S.btnP("#f472b6")}>Ekle</button>
          </div>
        </Modal>
      )}

      {showDgModal&&(
        <Modal onClose={()=>setShowDgModal(false)}>
          <div style={{fontWeight:"bold",fontSize:17,marginBottom:16,color:"#f472b6"}}>{editDg?"Düzenle":"🎂 Doğum Günü Ekle"}</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9,marginBottom:9}}>
            <div><div style={{fontSize:12,color:"#555",marginBottom:4}}>Ad *</div><input value={dgf.ad} onChange={e=>setDgf(p=>({...p,ad:e.target.value}))} style={S.input}/></div>
            <div><div style={{fontSize:12,color:"#555",marginBottom:4}}>Soyad</div><input value={dgf.soyad} onChange={e=>setDgf(p=>({...p,soyad:e.target.value}))} style={S.input}/></div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:9,marginBottom:9}}>
            <div>
              <div style={{fontSize:12,color:"#555",marginBottom:4}}>Ay *</div>
              <select value={dgf.ay} onChange={e=>setDgf(p=>({...p,ay:Number(e.target.value),gun:1}))} style={S.input}>
                {MONTHS.map((a,i)=><option key={i} value={i+1}>{a}</option>)}
              </select>
            </div>
            <div>
              <div style={{fontSize:12,color:"#555",marginBottom:4}}>Gün *</div>
              <select value={dgf.gun} onChange={e=>setDgf(p=>({...p,gun:Number(e.target.value)}))} style={S.input}>
                {Array.from({length:daysInMonth(2024,dgf.ay-1)},(_,i)=><option key={i+1} value={i+1}>{i+1}</option>)}
              </select>
            </div>
            <div>
              <div style={{fontSize:12,color:"#555",marginBottom:4}}>Yıl</div>
              <input placeholder="1995" type="number" value={dgf.yil} onChange={e=>setDgf(p=>({...p,yil:e.target.value}))} style={S.input}/>
            </div>
          </div>
          <select value={dgf.iliski} onChange={e=>setDgf(p=>({...p,iliski:e.target.value}))} style={{...S.input,marginBottom:9}}>
            {ILISKI.map(il=><option key={il} value={il}>{il}</option>)}
          </select>
          <textarea placeholder="Not..." value={dgf.not} onChange={e=>setDgf(p=>({...p,not:e.target.value}))} rows={2} style={{...S.input,resize:"vertical",marginBottom:12}}/>
          <div style={{display:"flex",gap:5,marginBottom:18}}>{COLORS.map(c=><button key={c} onClick={()=>setDgf(p=>({...p,color:c}))} style={{width:24,height:24,borderRadius:"50%",background:c,border:dgf.color===c?"3px solid #fff":"2px solid #333",cursor:"pointer",outline:"none"}}/>)}</div>
          <div style={{display:"flex",gap:7,justifyContent:"flex-end"}}>
            <button onClick={()=>{setShowDgModal(false);setEditDg(null);}} style={S.btnG}>İptal</button>
            <button onClick={saveDg} style={S.btnP("#f472b6")}>Kaydet</button>
          </div>
        </Modal>
      )}

      {showHedefModal&&(
        <Modal onClose={()=>{setShowHedefModal(false);setEditHedef(null);}}>
          <div style={{fontWeight:"bold",fontSize:17,marginBottom:16,color:hf.color}}>{editHedef?"Hedef Düzenle":"🎯 Yeni Hedef"}</div>
          <input placeholder="Hedef başlığı *" value={hf.baslik} onChange={e=>setHf(p=>({...p,baslik:e.target.value}))} style={{...S.input,marginBottom:9}}/>
          <textarea placeholder="Açıklama (opsiyonel)..." value={hf.aciklama} onChange={e=>setHf(p=>({...p,aciklama:e.target.value}))} rows={3} style={{...S.input,resize:"vertical",marginBottom:9}}/>
          <div style={{fontSize:12,color:"#555",marginBottom:6}}>Kategori</div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:6,marginBottom:12}}>
            {HEDEF_KATEGORILER.map(k=>(
              <button key={k.id} onClick={()=>setHf(p=>({...p,kategori:k.id}))} style={{padding:"7px 4px",borderRadius:9,border:`1.5px solid ${hf.kategori===k.id?hf.color:"#252535"}`,background:hf.kategori===k.id?`${hf.color}20`:"none",cursor:"pointer",fontFamily:"inherit",textAlign:"center"}}>
                <div style={{fontSize:16}}>{k.icon}</div>
                <div style={{fontSize:9,color:hf.kategori===k.id?hf.color:"#555",marginTop:2}}>{k.label}</div>
              </button>
            ))}
          </div>
          <div style={{fontSize:12,color:"#555",marginBottom:6}}>Renk</div>
          <div style={{display:"flex",gap:5,marginBottom:14}}>{COLORS.map(c=><button key={c} onClick={()=>setHf(p=>({...p,color:c}))} style={{width:24,height:24,borderRadius:"50%",background:c,border:hf.color===c?"3px solid #fff":"2px solid #333",cursor:"pointer",outline:"none"}}/>)}</div>
          <div style={{fontSize:12,color:"#555",marginBottom:8}}>Alt Adımlar (opsiyonel)</div>
          <div style={{display:"flex",gap:7,marginBottom:10}}>
            <input placeholder="Adım ekle... (Enter)" value={yeniAdim} onChange={e=>setYeniAdim(e.target.value)} onKeyDown={e=>e.key==="Enter"&&adimEkle()} style={{...S.input,flex:1}}/>
            <button onClick={adimEkle} style={{...S.btnP(hf.color),padding:"9px 14px",fontSize:13}}>+</button>
          </div>
          {hf.adimlar.length>0&&(
            <div style={{background:"#111118",borderRadius:10,padding:"10px 12px",marginBottom:14,border:"1px solid #2e2e3e"}}>
              {hf.adimlar.map((a,i)=>(
                <div key={a.id} style={{display:"flex",alignItems:"center",gap:8,padding:"5px 0",borderBottom:i<hf.adimlar.length-1?"1px solid #1e1e2e":"none"}}>
                  <div style={{width:14,height:14,borderRadius:"50%",border:`2px solid ${hf.color}`,flexShrink:0}}/>
                  <span style={{flex:1,fontSize:13,color:"#ccc"}}>{a.metin}</span>
                  <button onClick={()=>setHf(p=>({...p,adimlar:p.adimlar.filter(x=>x.id!==a.id)}))} style={{background:"none",border:"none",color:"#f87171",cursor:"pointer",fontSize:13}}>✕</button>
                </div>
              ))}
            </div>
          )}
          <div style={{display:"flex",gap:7,justifyContent:"flex-end"}}>
            <button onClick={()=>{setShowHedefModal(false);setEditHedef(null);}} style={S.btnG}>İptal</button>
            <button onClick={saveHedef} style={S.btnP(hf.color)}>Kaydet</button>
          </div>
        </Modal>
      )}

      {/* YEDEK MODAL */}
      {showExport&&(
        <Modal onClose={()=>setShowExport(false)}>
          <div style={{fontWeight:"bold",fontSize:17,marginBottom:6,color:accent}}>💾 Veri Yedekleme</div>
          <div style={{fontSize:12,color:"#666",marginBottom:20}}>Verilerini JSON dosyası olarak kaydedebilir ya da daha önce aldığın yedeği yükleyebilirsin.</div>
          <div style={{background:"#111118",borderRadius:12,padding:"16px 18px",marginBottom:16,border:"1px solid #252535"}}>
            <div style={{fontWeight:"bold",fontSize:13,color:"#e8e4dc",marginBottom:8}}>Mevcut Veriler</div>
            {[["📝","Notlar",notes.length],["✅","Görevler",todos.length],["📅","Etkinlikler",events.length],["🎓","Dersler",dersler.length],["🎂","Doğum Günleri",dogumGunleri.length],["🎯","Hedefler",hedefler.length]].map(([ic,ad,sayi])=>(
              <div key={ad} style={{display:"flex",justifyContent:"space-between",fontSize:13,color:"#888",padding:"4px 0"}}><span>{ic} {ad}</span><span style={{color:accent,fontWeight:"bold"}}>{sayi}</span></div>
            ))}
          </div>
          <button onClick={exportData} style={{...S.btnP(accent),width:"100%",marginBottom:10}}>Yedeği İndir (.json)</button>
          <label style={{display:"block",padding:"10px 20px",borderRadius:9,background:"#252535",color:"#aaa",cursor:"pointer",fontFamily:"inherit",fontSize:14,textAlign:"center",boxSizing:"border-box"}}>
            Yedeği Yükle
            <input type="file" accept=".json" onChange={importData} style={{display:"none"}}/>
          </label>
          <div style={{fontSize:11,color:"#444",marginTop:14,textAlign:"center"}}>Yedek dosyaları şifreli değildir. Güvenli bir yerde saklayın.</div>
        </Modal>
      )}

    </div>
  );
}
